package main

import (
    "github.com/gin-gonic/gin"
    "library-api/cassandra"
    "library-api/handlers"
)

func main() {
    cassandra.Init()

    router := gin.Default()
    router.POST("/books", handlers.AddBook)
    router.POST("/users", handlers.AddUser)
    router.POST("/borrow", handlers.BorrowBook)
    router.Run(":8080")
}